const app = require(`${__dirname}/app`);

const port = 3000;

const server = app.listen(port, () => {
    console.log("The server is running on port: ", port, "..");
});
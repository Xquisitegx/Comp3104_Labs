const express = require("express");
const router = express.Router();

const controller = require("./controller");

router.get("/hello", controller.HelloJS);
router.get("/user", controller.getUserInformation);
router.post("/user/:firstname/:lastname", controller.postUserInformation);

module.exports = router;
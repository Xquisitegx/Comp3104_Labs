exports.HelloJS = (req, res, next) => {
    res.status(300).send("Hello Express JS");
}

exports.getUserInformation = (req, res, next) => {
    res.status(300).json({
        firstname: req.query.firstname,
        lastname: req.query.lastname
    });
}

exports.postUserInformation = (req, res, next) => {
    res.status(301).json({
        firstname: req.params.firstname,
        lastname: req.params.lastname
    });
}